﻿define([
    'vue',
    'libs/vue-router.min',
    "models/Home/App/App",
    'models/Home/App/Index',
    'models/Home/App/Girl',
    'models/Home/App/Boy',
    'models/Home/App/Publish',
    'models/Home/App/Rank',
    'models/Home/App/Category',
    'models/Home/App/Recharge',
    'models/Home/App/BookShelf'
], function (
    Vue,
    VueRouter,
    App,
    Index,
    Girl,
    Boy,
    Publish,
    Rank,
    Category,
    Recharge,
    BookShelf
   ) {
    // 声明路由
    Vue.use(VueRouter);
    // 实例化
    var router = new VueRouter({
        hashbang: false
    });
    // 配置路径
    router.map({
        /* 书架 */
        '/BookShelf': {
            component: BookShelf
        },
        '/': {
            component: App,
            subRoutes: {
                /* 女生榜单 */
                '/Girl': {
                    component: Girl,
                    bgClass: "Girl"
                },
                /* 男生榜单 */
                '/Boy': {
                    component: Boy,
                    bgClass: "Boy"
                },
                /* 出版榜单 */
                '/Publish': {
                    component: Publish,
                    bgClass: "Publish"
                },
                /* 排行榜 */
                '/Rank': {
                    component: Rank
                },
                /* 分类 */
                'Category': {
                    component: Category
                },
                /* 充值 */
                '/Recharge': {
                    component: Recharge
                },
                /* 首页 */
                '/': {
                    component: Index,
                    bgClass: "Boy"
                }
            }
        }
    });
    // 运行
    router.start(Vue.extend({}), 'body');
});