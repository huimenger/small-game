﻿define(['vue', 'jquery', 'text!models/Home/App/Tpl/Recharge.html', "commons/StatisticsTool", "eui/Dialog", "eui/Toast", "commons/Browser"], function (Vue, $, Tpl, tool, dialog, toast, browser) {

    // 数据缓存
    var cache = {
        wholePage: false,
        isLoaded: false,
        list: [],
        isSelectMoney: 0,

        money: 0,
        channelId: tool.getAppId(),
        childChannelId: tool.getSubAppId(),
        platform: browser.isApple ? "iPhone" : "Android",

        standardSize: "375",//标准屏幕尺寸，按照iphone6来的 
        //isLogin: true  //默认是登录的
    };

    return Vue.extend({
        data: function () {
            return cache;
        },
        template: Tpl,
        ready: function () {
            var self = this;

            $(".footer").hide();
            self.resize();
            if (!self.isLoaded) {
                self.getData();
            }

            $(window).resize(function () {  //随着窗口大小改变
                self.resize();
            });
        },
        methods: {
            resize: function () {
                var self = this;
                //根据手机屏幕大小缩放substance这个div，以适应手机
                var currentSize = $(window).width(), //获取屏幕尺寸
                    divHeight = $("#p_recharge .substance").height(), //获取屏幕尺寸
                    multiple = currentSize / self.standardSize;
                $("#p_recharge .substance").css("-webkit-transform", "scale(" + multiple + ")");
                $("#p_recharge .recharge_wrap").css("height", divHeight * multiple + 10 + "px");
            },
            getData: function () {
                var self = this;

                toast.showProgress("加载中");
                $.get("/WebApi/Order/FindOrderProducts",
                    {},
                    function (result) {
                        toast.hide();
                        if (result.status == 1) {
                            self.list = result.data;

                            self.money = self.list[0].money;
                            Vue.nextTick(function () {
                                self.resize();
                            });
                            self.isLoaded = true;

                            //等数据加载完成再把充值页面展示出来
                            self.wholePage = true;
                            $(".footer").show();
                        } else {
                            toast.showError(result.message);
							//未登录 跳转去登录
							if (result.code == "1001") {
							    location.href = "/webapp/account/login.html?redirect=/webapp/home/index.html#/Recharge";
							    return;
							}
                        }
                    }, "json");
            },
            selectMoney: function (index, item) {
                this.isSelectMoney = index;
                this.money = item.money;
            },
            openWindow: function () {
                if (browser.isWeixin) {
                    if (location.href.indexOf("//m.ireadercity.com") != -1) {
                        location.href = "/WebApp/WechatPublicOrder/Pay.html?money=" + this.money + "&platform=" + this.platform;
                    } else {
                        $("#payMethod").val("wechat");
                        $('#form').submit();
                    }
                } else {
                    dialog.show({
                        title: "充值方式",
                        html: '',
                        closeable: true,  //是否有关闭图标
                        btns: [
                            {
                                text: "微信",
                                style: 1,
                                callback: function () {
                                    $("#payMethod").val("wechat");
                                    $('#form').submit();
                                }
                            },
                            {
                                text: "支付宝",
                                style: 1,
                                callback: function () {
                                    $("#payMethod").val("alipay");
                                    $('#form').submit();
                                }
                            }
                        ]
                    });
                }
            }
        }
    });
});