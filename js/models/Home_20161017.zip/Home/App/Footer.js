﻿define(['vue', 'text!models/Home/App/Tpl/Footer.html', 'commons/Download', 'commons/StatisticsTool', "commons/Config"], function (Vue, Tpl, Download, stat, config) {
    return Vue.extend({
        template: Tpl,
        data: function () {
            return {
                isShowDownload: config.isShowDownload(stat.getAppId()),
            }
        },
        methods: {
            download: function () {
                Download.download();
            }
        }
    });
});