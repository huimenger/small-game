﻿define(['vue', 'text!models/Home/App/Tpl/ActionBar.html', "commons/Browser"], function (Vue, Tpl, browser) {
    return Vue.extend({
        template: Tpl,
        props: {
            title: "书香云集",
            fixed: {
                type: Boolean,
                default: false
            },
            showBack: {
                type : Boolean,
                default: true
            }
        }
    });
});