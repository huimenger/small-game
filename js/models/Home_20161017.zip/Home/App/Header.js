﻿define(['vue', "jquery", "commons/InitData", 'text!models/Home/App/Tpl/Header.html', 'commons/Download', 'commons/StatisticsTool', "commons/Config"], function (Vue, $, InitData, Tpl, Download, stat, config) {

    InitData = JSON.parse(InitData);

    return Vue.extend({
        template: Tpl,
        props: {
            userico: {
                default: true,
                type: Boolean
            }
        },
        data: function () {
            return {
                isShowDownload: config.isShowDownload(stat.getAppId()),
                cover: InitData.cover || "",
                coin: InitData.coin || 0
            };
        },
        methods: {
            download: function () {
                Download.download();
            }
        }
    });
});